package com.self.FootballWebSite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballWebSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
